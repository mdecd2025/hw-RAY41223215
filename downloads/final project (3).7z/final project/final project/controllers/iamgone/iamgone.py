from controller import Robot, Keyboard
import time

def run_robot():
    # Create the Robot instance
    robot = Robot()

    # Get simulation time step
    timestep = int(robot.getBasicTimeStep())

    # Get motor and keyboard devices
    motor = robot.getDevice('motor')
    keyboard = robot.getKeyboard()
    keyboard.enable(timestep)

    # Initial motor position
    initial_position = 0.0
    target_position = 38 * 3.14159 / 180  # Convert 38 degrees to radians

    # Set motor to position control mode
    motor.setPosition(initial_position)

    # Flag to track motor state
    triggered = False
    returning = False

    # Main control loop
    while robot.step(timestep) != -1:
        key = keyboard.getKey()

        # When 'K' key is pressed and not yet triggered
        if key == ord('K') and not triggered:
            motor.setPosition(target_position)
            triggered = True
            returning = False
            print("Moved to 38 degrees")

        # Wait until motor finishes turning, then return to original position
        if triggered and not returning:
            # Wait for a short time (or sensor logic if available)
            robot.step(timestep * 10)  # About 320ms
            motor.setPosition(initial_position)
            returning = True
            print("Returning to initial position")

        # Reset state when done
        if triggered and returning:
            # Wait again briefly to simulate completion
            robot.step(timestep * 10)
            triggered = False
            returning = False

if __name__ == "__main__":
    run_robot()
