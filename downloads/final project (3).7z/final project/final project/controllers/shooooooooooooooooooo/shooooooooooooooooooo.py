from controller import Robot
import time

def run_robot():
    # Create the Robot instance
    robot = Robot()

    # Get simulation time step
    timestep = int(robot.getBasicTimeStep())

    # Get motor and keyboard devices
    motor = robot.getDevice('motor1')
    keyboard = robot.getKeyboard()
    keyboard.enable(timestep)

    # Convert degrees to radians
    def deg2rad(deg):
        return deg * 3.14159 / 180

    # Set initial motor position to -5 degrees (蓄力)
    motor.setPosition(deg2rad(-10))
    # Wait for a short time (e.g., 1 second) to complete the back movement
    for _ in range(int(300 / timestep)):  # wait ~1 second
        if robot.step(timestep) == -1:
            return

    # Main control loop
    while robot.step(timestep) != -1:
        # Move to 38 degrees
        motor.setPosition(deg2rad(38))

if __name__ == "__main__":
    run_robot()
